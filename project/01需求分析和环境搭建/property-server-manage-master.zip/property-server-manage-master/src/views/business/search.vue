<template>
  <div>
    <h1>房产查询</h1>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
