<template>
  <div>
    <h1>我的消息</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
