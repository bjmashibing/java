<template>
  <div>
    <h1>请修管理</h1>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
