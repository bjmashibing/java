<template>
  <div>
    <addGuide></addGuide>
  </div>
</template>

<script>
import addGuide from './addGuide/StepForm'
export default {
  components: {
    addGuide
  }
}
</script>
