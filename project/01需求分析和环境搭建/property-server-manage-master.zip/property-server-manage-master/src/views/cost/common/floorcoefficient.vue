<template>
  <div>
    <h1>楼层系数</h1>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
