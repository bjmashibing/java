<template>
  <div>
    <h1>初始化仪表</h1>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
