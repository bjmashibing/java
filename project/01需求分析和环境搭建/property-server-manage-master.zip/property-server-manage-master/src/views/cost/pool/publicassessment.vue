<template>
  <div>
    <h1>公摊费分布</h1>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
